Archive bundle test fixture — real files inside.
LineChart.png and GrayscaleScan.png come from the Media Gallery.
